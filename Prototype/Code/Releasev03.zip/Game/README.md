Title: Tengai v0.2

Update: character animations and simple background


Controls: A,D,S,W to move player
